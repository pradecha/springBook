package com.prog.test;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
		

public class mainTest {

	public static void main(String[] args) {
		
		
		pasent p1 = new pasent("Kunal",27,"Corona",5666);
		pasent p2 = new pasent("Bimal",28,"Fever",5666);
		pasent p3 = new pasent("Rupesh",22,"Corona",9990);
		pasent p4 = new pasent("Raj",29,"Corona",4500);
		pasent p5 = new pasent("Pop",24,"Corona",5666);
		
		List<pasent> pasents = Arrays.asList(p1,p2,p3,p4,p5);
		pasents.stream().filter(p -> p.getSuffPasent().equals("Corona") && p.getPasentAge() <25) .forEach(System.out::println);
		Double getAvg = pasents.stream().filter(p -> p.getSuffPasent().equals("Corona")).collect(Collectors.averagingDouble(pasent::getAvgAmount));
		System.out.println("Get Avg is : " + getAvg);
		
		StringBuilder builder = new StringBuilder("Hello");
		builder.append("Java");
		System.out.println(builder);
		
		

		
		
	}

}
