package com.prog.test;

public class pasent {
	
	private String pasentName;
	private int pasentAge;
	private String suffPasent;
	private int avgAmount;
	
	
	public pasent() {
		
	}
	
	
	public String getPasentName() {
		return pasentName;
	}
	public void setPasentName(String pasentName) {
		this.pasentName = pasentName;
	}
	public int getPasentAge() {
		return pasentAge;
	}
	public void setPasentAge(int pasentAge) {
		this.pasentAge = pasentAge;
	}
	public String getSuffPasent() {
		return suffPasent;
	}
	public void setSuffPasent(String suffPasent) {
		this.suffPasent = suffPasent;
	}
	public int getAvgAmount() {
		return avgAmount;
	}
	public void setAvgAmount(int avgAmount) {
		this.avgAmount = avgAmount;
	}
	public pasent(String pasentName, int pasentAge, String suffPasent, int avgAmount) {
		super();
		this.pasentName = pasentName;
		this.pasentAge = pasentAge;
		this.suffPasent = suffPasent;
		this.avgAmount = avgAmount;
	}


	@Override
	public String toString() {
		return "pasent [pasentName=" + pasentName + ", pasentAge=" + pasentAge + ", suffPasent=" + suffPasent
				+ ", avgAmount=" + avgAmount + "]";
	}
	
	
	
	
	
	
	
	

}
