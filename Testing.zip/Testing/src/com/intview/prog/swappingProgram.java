package com.intview.prog;

public class swappingProgram {

	public static void main(String[] args) {
		
		
		    int temp;
		    int x = 100;
		    int y = 200;
		     
		    //Swapping in steps
		    temp = x;
		    x = y;
		    y = temp;
		     
		    //Verify swapped values
		    System.out.println("x = " + x + " and y = " + y);
		    
		    int temp1;
		    int x1 = 21;
		    int y1 = 23;
		    
		    temp1 = x1;
		    x1 = y1;
		    y1 = temp1;
		    
		    System.out.println("X1 = " + x1 + " and Y1 = " + y1);
		    

	}

}
