package com.intview.prog;

public class texting {

	public static void main(String[] args) {
		
		
		StringBuffer strBuffer = new StringBuffer();
		strBuffer.append("Hello Kishor");
		System.out.println(strBuffer);
		
		StringBuilder strBuilder = new StringBuilder();
		strBuilder.append("Hello Keshu");
		System.out.println(strBuilder);
		System.out.println(); 
		
		
	       try {
				System.out.println("Inside try block");
				int i =10/0;
				System.exit(2);
				System.out.println("After system exit");
			}

			catch (Exception e) {
				System.out.println("Inside super class exception class block");
			}
	        finally{
				System.out.println("Finally block");
			}
		
		
	
	}

}
