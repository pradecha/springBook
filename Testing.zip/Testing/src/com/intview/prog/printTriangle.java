package com.intview.prog;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class printTriangle {

	public static void main(String[] args) {
		
		int i , j, row = 4;
		for(i=1; i<=row;i++)
		{
			for(j=1;j<=i;j++)
			{
				System.out.print(i + " ");
			}
				System.out.println();
		}
		
		
		//print start triangle 
		int v,q,rows=4;
		for(v=0;v<=rows;v++)
		{
			for(q=0;q<=v;q++)
			{
				System.out.print("*");
			}
				System.out.println();
		}
		
		
		int s,d,rowd=7;
		for(s=0; s<=rowd;s++)
		{
			for(d=0; d<=s;d++)
			{
				
			}
		}
		
		// Pattern Triangle 
		int x,y,numbers,n=7;
		for(x=0;x<n;x++)
		{
			numbers=1;
			for(y=0;y<=x;y++)
			{
				System.out.print(numbers + " ");
				numbers++;
			}
				System.out.println();
		}
			
	}

}
