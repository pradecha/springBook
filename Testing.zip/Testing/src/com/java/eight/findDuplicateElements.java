package com.java.eight;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class findDuplicateElements {

	public static void main(String[] args) {
		
        
        List<Integer> myList22 = Arrays.asList(1,2,3,4,5,6,3,4,5);
        Set<Integer> set22 = new HashSet<>();
        myList22.stream().filter(i -> !set22.add(i)).forEach(System.out::println);
        
        System.out.println("__________________________");
        
        Stream<Integer> strm55 = Stream.of(1,2,3,4,5,6,3,2);
        Set<Integer> set55 = new HashSet<>();
        strm55.filter(k -> !set55.add(k)).forEach(System.out::println);
        
        System.out.println("_________Br___________");
        

        
        //___________________Verification purpose___________
        
        for(int i= 0; i<=10; i++)
        {
        	System.out.println("Pradeep Chaudhary");
        }
        
		  String[] myName = new String[10]; Arrays.parallelSetAll(myName, i ->
		  "Shreyash"); System.out.print(Arrays.toString(myName));
		
    	
    	String[] elements = {"Pradeep", "Kumar", "Nisha", "Kanel", "Romiyoo", "Divya", "Punkaj", "Deepash", "Kunal", "Ramnjeet"};   
    	for (String s: elements) {           
    	    //Do your stuff here
    		System.out.println(s);
    	}
    	
    	
    	System.out.println("__________________________________________");
    	String[] myData = new String[10]; 
    	Arrays.parallelSetAll(myData, i -> "Bhavya"); System.out.print(Arrays.toString(myData));
    	
    	
    			  
    			  

	}

}
