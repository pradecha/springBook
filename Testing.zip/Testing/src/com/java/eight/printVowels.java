package com.java.eight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

 class printVowels {

	public static void main(String[] args) {
		
		
		String str ="Java programming language";
		str = str.toLowerCase();
		//Initiate integer for Count Vowels Program
		int countVowels = 0;
		int countConsonants =0;
		for(int i =0; i<str.length(); i++)
		{
			if(str.charAt(i) =='a' ||
			   str.charAt(i) =='e' ||
			   str.charAt(i) =='i' ||
			   str.charAt(i) =='o' ||
			   str.charAt(i) =='u' )
			{
				System.out.println("Vowles found: " + str.charAt(i) + " at index " + i);
				//Count Vowels Program
				countVowels++;
			}
			
			else if(str.charAt(i) != ' '){
				countConsonants++;
	         }
		}		//Pass variable to display Count Vowels Program
				System.out.println("Total founded Vowles is: " +countVowels);
				System.out.println("Total Consonants is " + countConsonants);
			
	}

}
