package com.java.eight;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class findDublicateValue {

	public static void main(String[] args) {


		/*
		 * List<Integer> list = Arrays.asList(33,44,55,33,55,66,77,88,99,22,44,55);
		 * Set<Integer> result = findDuplicateBySetAdd(list);
		 * 
		 * }
		 * 
		 * private static <T> Set<T> findDuplicateBySetAdd(List<T> list) { Set<T> items
		 * = new HashSet<>();
		 * 
		 * return list.stream().filter(n -> items.add(n)).collect(Collectors.toSet());
		 */
		
		List<String> list = Arrays.asList("A", "B", "C", "D", "A", "B", "C", "F");
		// Get list without duplicates
		List<String> distinctItems = list.stream().distinct().collect(Collectors.toList());
		// Let's verify distinct elements
		System.out.println(distinctItems);
		
		
		//2nd Method 
		List<Integer> listInt = Arrays.asList(1,2,1,2,3,4,5,6);
		List<Integer> duplicateElements = listInt.stream().distinct().collect(Collectors.toList());
		System.out.println("List of Duplicate elemnts is: " + duplicateElements);
	
	}

}
