package com.java.eight;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class evenNumber {

	public static void main(String[] args) {
		
		
		 List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32);
         myList.stream().filter(n -> n%2 == 0).forEach(System.out::println);
         
         System.out.println("Odd number is:");
         List<Integer> list77= Arrays.asList(1,2,3,4,5,6,7,8,9,35,49,25,63);
         list77.stream().filter(i -> i%2 != 0).forEach(System.out::println);
         System.out.println("Divisible by 5 or 7 is : ");
         list77.stream().filter(i -> i%5 == 0 || i%7 ==0).forEach(System.out::println);
         System.out.println("___________Break__________ ");
         //_______________________________________
         
         System.out.println("Even number is:");
         Stream<Integer> strm = Stream.of(1,2,3,4,5,6,7,8,9);
         strm.filter(j -> j%2 ==0).forEach(System.out::println);

         
         
         
         

	}

}
