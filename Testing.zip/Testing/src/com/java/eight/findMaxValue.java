package com.java.eight;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class findMaxValue {

	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(12,44,56,87,234,246,764,342);
		
		Integer maxValue = list.stream().max(Integer::compare).get();
		System.out.println("Max value is : " + maxValue);
		
		List<Integer> list99 = Arrays.asList(12,44,55,66,7788,99);
		Integer maxValue99 = list99.stream().max(Integer::compare).get();
		System.out.println(maxValue99);
		
		
		Integer minValue = list.stream().min(Integer::compare).get();
		System.out.println("Min value is : " + maxValue);
		
		List<Integer> listMX = Arrays.asList(1,2,3,4,56,6);
		Integer findMXValue = listMX.stream().max(Integer::compare).get();
		System.out.println("List MAX Value is : " + findMXValue);
		
		System.out.println("_______________");
		Stream<Integer> strm89 = Stream.of(1,2,3,4,5);
		Integer maxValueIs = strm89.max(Integer::compare).get();
		System.out.println("Max value is: " + maxValueIs);
		
		List<Integer> list22 = Arrays.asList(12,44,56,87,234,246,764,342);
	    Collections.reverseOrder();
	    
	    
	    Stream<?> st = Stream.of(22,33,4,44,667,88);
	    
	    List<?> list55 = st.collect(Collectors.collectingAndThen(Collectors.toList(), 
	    					rev -> {Collections.reverse(rev); return rev; }));
	    System.out.println(list55);
	    
	    
	   Stream<?> st44 = Stream.of(1,2,3,4,5);
	   List<?> list44 = st44.collect(Collectors.collectingAndThen(Collectors.toList(), rev44 -> { Collections.reverse(rev44); return rev44; }));
	   System.out.println(list44);
				
	}

}
