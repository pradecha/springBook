package com.java.eight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class reverseString {

	public static void main(String[] args) {
		
		
		String str = "Automation";
        StringBuilder str2 = new StringBuilder();
        str2.append(str);
        str2 = str2.reverse();     // used string builder to reverse
        System.out.println(str2);
        
      List<String> countLastElement = new ArrayList<>();
      countLastElement.add("Last Elements");
      countLastElement.forEach(str99 -> System.out.println(str99));
      System.out.println("Count Last element is : \n");
      countLastElement.stream().map(str99 -> str99.split("\\s"))
      	      					.peek(strArr -> System.out.println(strArr[strArr.length -1]))
      	      					.map(strArr -> strArr[strArr.length -1].length())
      	      					.forEach(strLength -> System.out.println(strLength));
      
      List<Integer> list66 = Arrays.asList(12,233,5,6,7,7898,334);
      Collections.reverse(list66);
      System.out.println("Reverse list is : " + list66);
      
	}
}

      
