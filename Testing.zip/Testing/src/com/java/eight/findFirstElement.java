package com.java.eight;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

public class findFirstElement {

	public static void main(String[] args) {
		
		List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
        myList.stream().findFirst().ifPresent(System.out::println);
        
        List<Integer> findElements = Arrays.asList(1,2,3,4,5,44,78,41,5,589);
        findElements.stream().map(i -> i + "").filter(i -> i.startsWith("4")).forEach(System.out::println);
        System.out.println("Find elements start with 5 : ");
        findElements.stream().map(j -> j + "").filter(j -> j.startsWith("5")).forEach(System.out::println);
        
        System.out.println("Find first element is: ");
        List<Integer> list777 = Arrays.asList(1,3,666,8,9);
        Integer findMax = list777.stream().max(Integer::compare).get();
        System.out.println("Max element is: " + findMax);
        
        System.out.println("Dublicate elements are : ");
        Set<Integer> dubValue = new  HashSet<>();
        findElements.stream().filter(y -> !dubValue.add(y)).forEach(System.out::println);
        
        
        System.out.println("Find first element is: ");
        findElements.stream().findFirst().ifPresent(System.out::println);

	}

}
