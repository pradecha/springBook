package com.java.eight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class intermediateTerminalOperation {
	
	public static void main(String[] args) {
	
	List<String> laptopList = new ArrayList();
    laptopList.add("DELL");
    laptopList.add("ACER");
    laptopList.add("HCL");

    // Intermediate operation
    laptopList.sort((p1, p2) -> p1.compareTo(p2));

    // Terminal Operation
    laptopList.forEach(a -> {
       System.out.println(a);
    });
    
    	
 }

}
