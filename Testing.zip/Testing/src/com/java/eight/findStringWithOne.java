package com.java.eight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

//https://javahungry.blogspot.com/2020/05/java-8-coding-and-programming-interview-questions.html

public class findStringWithOne {

	public static void main(String[] args) {
	
	List<Integer> myList = Arrays.asList(10,15,18,49,25,98,32,23);
    myList.stream()
          .map(s -> s + "") // Convert integer to String
          .filter(s -> s.startsWith("1") || s.startsWith("3"))
          .forEach(System.out::println);
    
    List<Integer> list44 = Arrays.asList(1,22,33,44,55,12,31,41,45,55,56,59);
    
    list44.stream().map( j -> j + "").filter(j -> j.startsWith("1") || j.startsWith("5")).forEach(System.out::println);
    
    
    System.out.println("__________Print Value_____________");
    List<Integer> list55 = Arrays.asList(1,3,4,11,14,16,34,2,24,27);
    list55.stream().map(i -> i + "").filter(i -> i.startsWith("1") || i.startsWith("2")).forEach(System.out::println);
    
    
    System.out.println("___________Print Vowels is : ___________");
    List<Integer> list666 = Arrays.asList(1,2,3,4,5,1,2,4,6,7,8);
    Set<Integer> set666 = new HashSet<>();
    list666.stream().filter(b -> !set666.add(b)).forEach(System.out::println);

}
}
