package com.java.eight;

import java.util.Comparator;
import java.util.stream.Stream;

public class descendingOrder {

	public static void main(String[] args) {
		
		
		Stream<Integer> numStream = Stream.of(1,3,5,4,2);

		numStream.sorted( Comparator.reverseOrder()).forEach(System.out::println);
		
		System.out.println("_____________________________");
		Stream<Integer> str66 = Stream.of(1,2,3,45,6,7);
		str66.sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		System.out.println("_____________________________");
		
		
		 // Reverse String
		 String str = "Automation";
         StringBuilder str2 = new StringBuilder();
         str2.append(str);
         str2 = str2.reverse();     // used string builder to reverse
         System.out.println(str2);
        
        
	}

}
