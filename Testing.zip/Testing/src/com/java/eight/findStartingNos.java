package com.java.eight;

import java.util.Arrays;
import java.util.List;

public class findStartingNos {

	public static void main(String[] args) {
		
		
		List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32);
        myList.stream()
              .map(s -> s + "") // Convert integer to String
              .filter(s -> s.startsWith("1"))
              .forEach(System.out::println);
        
        System.out.println("Find elemens start with 5 is : ");
        List<Integer> listy = Arrays.asList(1,2,3,45,56,7787,49,444,33,356,947,999);
        listy.stream().map(k -> k + "").filter(k -> k.startsWith("4") || k.startsWith("3") || k.startsWith("9")).forEach(System.out::println);
	}

}
