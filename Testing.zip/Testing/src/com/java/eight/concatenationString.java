package com.java.eight;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class concatenationString {

	public static void main(String[] args) {
	
		
		List<String> list77 = Arrays.asList("Con","cate","nation");
		String str77 = list77.stream().collect(Collectors.joining());
		System.out.println(str77.toString());
		
		int a= 1;
		int b= 2;
		int c= 3;
		
		String str = String.valueOf(a) + b + c;
		System.out.println(str);

		
		List<String> list333 = Arrays.asList("Hye","Java");
		String str333 = list333.stream().collect(Collectors.joining());
		System.out.println("String Concatination is : " + str333);
		
		int h1 =1, h2 =2, h3 = 4;
		String strCon = String.valueOf(h1) + h2+h3;
		System.out.println(strCon);
		

		
		

	}

}
