package com.java.eight;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

public class reverseElements {

	public static void main(String[] args) {
		
		
		int number = 987654, reverse = 0;  
		while(number != 0)   
		{  
		int remainder = number % 10;  
		reverse = reverse * 10 + remainder;  
		number = number/10;  
		}  
		System.out.println("The reverse of the given number is: " + reverse);  
		
		Stream<Integer> strmList = Stream.of(1,2,4,56,7,8,8);
		Set<Integer> set = new HashSet<>();
		strmList.filter(i -> !set.add(i)).forEach(System.out::println);
		
		
	}
}
