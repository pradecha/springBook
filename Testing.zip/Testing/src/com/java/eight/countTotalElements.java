package com.java.eight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class countTotalElements {

	public static void main(String[] args) {
		
		
		// creating a list of Integers
        List<Integer> list = Arrays.asList(0, 2, 4, 6, 8, 10, 12);
  
        // Using count() to count the number
        // of elements in the stream and
        // storing the result in a variable.
        long total = list.stream().count();
  
        // Displaying the number of elements
        System.out.println(total);
        
        List<Integer> list44 = Arrays.asList(1,2,3,4,5,6,7,8,9);
        long e_total = list44.stream().count();
        System.out.println("Count of total elements is:" + e_total);
        
        //2nd method
        Stream<Integer> strm = Stream.of(1,2,3,4,5,6,7);
        Long counElement = strm.count();
        System.out.println("Total elements is :" + counElement);
              
        
        //3rd method
        List<Integer> list33 = new ArrayList<>();
        list33.add(1);
        list33.add(2);
        list33.add(3);
        list33.add(4);
        long countE = list33.stream().count();
        System.out.println("Count e : " +countE);
        
        
        
        

	}

}
