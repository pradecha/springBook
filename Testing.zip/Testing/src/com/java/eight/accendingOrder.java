package com.java.eight;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class accendingOrder {

	public static void main(String[] args) {
		
		Stream<Integer> numStream = Stream.of(1,3,5,4,2);
		numStream.sorted().forEach(System.out::println);
		
        System.out.println("Find elements start with 4 & 5 are : ");
		List<Integer> list = Arrays.asList(1,2,3,3,5,5,1,2,8,16,50);
		list.stream().map(i -> i + "").filter(i -> i.startsWith("5")).forEach(System.out::println);
		
		long countElement = list.stream().count();
		System.out.println("Total elements is : " + countElement);
		System.out.println("Reverse String");
		String str ="Hello String";
		StringBuilder strB = new StringBuilder();
		strB.append(str);
		strB = strB.reverse();
		System.out.println("Reverse of the string is : " + strB);
		
		
	}

}
