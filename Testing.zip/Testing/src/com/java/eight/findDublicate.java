package com.java.eight;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class findDublicate {
	public static void main(String[] args) {
		
        
        List<Integer> list66 = Arrays.asList(1,2,3,4,5,6,7,2,4,2,5);
        Set<Integer> result66 = findDublicateValue(list66);
        result66.forEach(System.out::println);
    }
    public static <T> Set<T> findDublicateValue(List<T> list66){
		return list66.stream().filter(j -> Collections.frequency(list66, j) >1 ).collect(Collectors.toSet());
    	
    }
    

}
