package com.java.eight;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Stream;

public class fibonacciSeries {

	public static void main(String[] args) {
		
		
		//Take input from the user
        //Create instance of the Scanner class
       // Scanner sc=new Scanner(System.in);
        int t1 = 0, t2 = 1;
        System.out.print("Enter the number of terms: ");
       // int n=sc.nextInt();   //Declare and Initialize the number of terms 
        int n=13;
        System.out.println("First " + n + " terms of fibonnaci series: "); 
        //Print the fibonacci series
        for (int i = 1; i <= n; ++i)
        {
            System.out.print(t1 + " ");
            int sum = t1 + t2;
            t1 = t2;
            t2 = sum;
        }
        System.out.println("Hello <br/> pradeep");
        
        		int p1 = 0, p2 = 1;
        		int n1 = 8;
        		for (int  j= 1; j <= n1; ++j)
        		{
        			System.out.println(p1 + " ");
        			int sum1 = p1+p2;
        			p1 = p2;
        			p2 = sum1;
        		}
        		
        		
        System.out.println("_______________________________");
		
    	String str ="Hello String";
    	str = str.toLowerCase();
    	int countVowels=0;
    	for(int d=0; d<=str.length();d++)
    	{
    		if(str.charAt(d) == 'a' ||
    		   str.charAt(d) == 'e' ||
    		   str.charAt(d) == 'i' ||
    		   str.charAt(d) == 'o' ||
    		   str.charAt(d) == 'u' )
    		{
    			System.out.println("Find Vowels is: " + str.charAt(d) + " index at : " + d);
    			countVowels++;
    		}
    	}
    	System.out.println("Total Vowels is : " + countVowels);
	}

}
